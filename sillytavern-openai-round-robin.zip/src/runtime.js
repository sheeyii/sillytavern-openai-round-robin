import path from 'node:path';

import { ensureConfigFile, loadConfig } from './config.js';
import { createProxyServer } from './proxy-server.js';

export async function startRuntime({ pluginDirectory, logger = console } = {}) {
    const examplePath = path.join(pluginDirectory, 'config.example.json');
    const configPath = process.env.ST_OPENAI_ROUND_ROBIN_CONFIG
        ? path.resolve(process.env.ST_OPENAI_ROUND_ROBIN_CONFIG)
        : path.join(pluginDirectory, 'config.json');

    const created = ensureConfigFile(configPath, examplePath);
    if (created) {
        logger.warn?.(`[openai-round-robin] Created ${configPath}. Edit it, enable targets, and restart SillyTavern.`);
    }

    const config = loadConfig(configPath);
    const proxy = createProxyServer(config, { logger });
    const address = await proxy.start();
    const printableHost = typeof address === 'object' && address?.family === 'IPv6'
        ? `[${address.address}]`
        : address.address;
    logger.info?.(`[openai-round-robin] Listening on http://${printableHost}:${address.port}/v1 with ${config.targets.filter(target => target.enabled).length} enabled target(s)`);
    return proxy;
}

