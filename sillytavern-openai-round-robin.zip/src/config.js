import fs from 'node:fs';
import path from 'node:path';

export class ConfigError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ConfigError';
    }
}

function expectObject(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new ConfigError(`${label} must be an object`);
    }
    return value;
}

function positiveInteger(value, fallback, label) {
    const result = value ?? fallback;
    if (!Number.isInteger(result) || result <= 0) {
        throw new ConfigError(`${label} must be a positive integer`);
    }
    return result;
}

function normalizeBaseUrl(value, label) {
    if (typeof value !== 'string' || !value.trim()) {
        throw new ConfigError(`${label} is required`);
    }

    let parsed;
    try {
        parsed = new URL(value.trim());
    } catch {
        throw new ConfigError(`${label} must be a valid HTTP(S) URL`);
    }

    if (!['http:', 'https:'].includes(parsed.protocol)) {
        throw new ConfigError(`${label} must use HTTP or HTTPS`);
    }
    parsed.hash = '';
    parsed.search = '';
    parsed.pathname = parsed.pathname.replace(/\/+$/, '');
    return parsed.toString().replace(/\/$/, '');
}

function normalizeHeaders(value, label) {
    if (value === undefined) {
        return {};
    }
    expectObject(value, label);
    return Object.fromEntries(Object.entries(value).map(([key, headerValue]) => {
        if (!key.trim() || typeof headerValue !== 'string') {
            throw new ConfigError(`${label} values must be strings`);
        }
        return [key.trim(), headerValue];
    }));
}

function normalizeRetryStatuses(value) {
    if (value === undefined || value === 'all') {
        return 'all';
    }
    if (!Array.isArray(value) || value.some(status => !Number.isInteger(status) || status < 400 || status > 599)) {
        throw new ConfigError('routing.failover.retryStatusCodes must be "all" or an array of HTTP error status codes');
    }
    return [...new Set(value)];
}

export function parseConfig(raw) {
    expectObject(raw, 'config');
    const rawServer = expectObject(raw.server ?? {}, 'server');
    const rawRouting = expectObject(raw.routing ?? {}, 'routing');
    const rawFailover = expectObject(rawRouting.failover ?? {}, 'routing.failover');

    const host = rawServer.host ?? '127.0.0.1';
    if (!['127.0.0.1', '::1'].includes(host)) {
        throw new ConfigError('server.host must be 127.0.0.1 or ::1; non-loopback listening is intentionally blocked');
    }

    const port = rawServer.port ?? 35697;
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new ConfigError('server.port must be an integer between 1 and 65535');
    }

    const localApiKey = rawServer.apiKey;
    if (typeof localApiKey !== 'string' || !localApiKey.trim()) {
        throw new ConfigError('server.apiKey is required');
    }

    const defaultModel = rawRouting.defaultModel ?? 'text';
    if (typeof defaultModel !== 'string' || !defaultModel.trim()) {
        throw new ConfigError('routing.defaultModel must be a non-empty string');
    }

    if (!Array.isArray(raw.targets)) {
        throw new ConfigError('targets must be an array');
    }

    const maxAttempts = rawFailover.maxAttempts ?? 0;
    if (!Number.isInteger(maxAttempts) || maxAttempts < 0) {
        throw new ConfigError('routing.failover.maxAttempts must be a non-negative integer (0 means all targets)');
    }

    const names = new Set();
    const targets = raw.targets.map((item, index) => {
        const label = `targets[${index}]`;
        expectObject(item, label);
        const name = item.name ?? `target-${index + 1}`;
        if (typeof name !== 'string' || !name.trim()) {
            throw new ConfigError(`${label}.name must be a non-empty string`);
        }
        if (names.has(name)) {
            throw new ConfigError(`${label}.name must be unique`);
        }
        names.add(name);

        const model = item.model;
        if (typeof model !== 'string' || !model.trim()) {
            throw new ConfigError(`${label}.model is required`);
        }
        const publicModel = item.publicModel ?? defaultModel;
        if (typeof publicModel !== 'string' || !publicModel.trim()) {
            throw new ConfigError(`${label}.publicModel must be a non-empty string`);
        }

        const apiKey = item.apiKey ?? '';
        if (typeof apiKey !== 'string') {
            throw new ConfigError(`${label}.apiKey must be a string`);
        }
        const authHeader = item.authHeader ?? 'Authorization';
        const authScheme = item.authScheme ?? 'Bearer';
        if (typeof authHeader !== 'string' || !authHeader.trim() || typeof authScheme !== 'string') {
            throw new ConfigError(`${label}.authHeader and authScheme must be strings`);
        }

        return {
            id: index,
            name: name.trim(),
            enabled: item.enabled !== false,
            publicModel: publicModel.trim(),
            baseUrl: normalizeBaseUrl(item.baseUrl, `${label}.baseUrl`),
            apiKey,
            model: model.trim(),
            authHeader: authHeader.trim(),
            authScheme: authScheme.trim(),
            headers: normalizeHeaders(item.headers, `${label}.headers`),
        };
    });

    return {
        server: {
            host,
            port,
            apiKey: localApiKey,
            requestBodyLimitBytes: positiveInteger(rawServer.requestBodyLimitMb, 32, 'server.requestBodyLimitMb') * 1024 * 1024,
            upstreamTimeoutMs: positiveInteger(rawServer.upstreamTimeoutMs, 120000, 'server.upstreamTimeoutMs'),
        },
        routing: {
            defaultModel: defaultModel.trim(),
            exposeTargetHeader: rawRouting.exposeTargetHeader !== false,
            failover: {
                enabled: rawFailover.enabled !== false,
                maxAttempts,
                retryStatusCodes: normalizeRetryStatuses(rawFailover.retryStatusCodes),
            },
        },
        targets,
    };
}

export function loadConfig(configPath) {
    let raw;
    try {
        raw = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    } catch (error) {
        if (error instanceof SyntaxError) {
            throw new ConfigError(`Invalid JSON in ${configPath}: ${error.message}`);
        }
        throw error;
    }
    return parseConfig(raw);
}

export function ensureConfigFile(configPath, examplePath) {
    if (fs.existsSync(configPath)) {
        return false;
    }
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.copyFileSync(examplePath, configPath, fs.constants.COPYFILE_EXCL);
    return true;
}
