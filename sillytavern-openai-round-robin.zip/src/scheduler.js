export class RoundRobinScheduler {
    constructor(targets) {
        this.pools = new Map();
        this.cursors = new Map();

        for (const target of targets) {
            if (!target.enabled) {
                continue;
            }
            const key = target.publicModel.toLowerCase();
            if (!this.pools.has(key)) {
                this.pools.set(key, []);
                this.cursors.set(key, 0);
            }
            this.pools.get(key).push(target);
        }
    }

    models() {
        return [...this.pools.values()].map(pool => pool[0].publicModel);
    }

    poolSize(model) {
        return this.pools.get(String(model).toLowerCase())?.length ?? 0;
    }

    next(model, excludedIds = new Set()) {
        const key = String(model).toLowerCase();
        const pool = this.pools.get(key);
        if (!pool?.length) {
            return null;
        }

        const start = this.cursors.get(key) ?? 0;
        for (let offset = 0; offset < pool.length; offset++) {
            const position = (start + offset) % pool.length;
            const target = pool[position];
            if (excludedIds.has(target.id)) {
                continue;
            }
            this.cursors.set(key, (position + 1) % pool.length);
            return target;
        }
        return null;
    }

    snapshot() {
        return [...this.pools.entries()].map(([model, targets]) => ({
            model: targets[0].publicModel,
            cursor: this.cursors.get(model) ?? 0,
            targets: targets.map(target => ({
                name: target.name,
                model: target.model,
            })),
        }));
    }
}

