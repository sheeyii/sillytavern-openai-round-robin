import crypto from 'node:crypto';
import http from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

import { RoundRobinScheduler } from './scheduler.js';

const HOP_BY_HOP_HEADERS = new Set([
    'connection',
    'content-encoding',
    'content-length',
    'host',
    'keep-alive',
    'proxy-authenticate',
    'proxy-authorization',
    'set-cookie',
    'te',
    'trailer',
    'transfer-encoding',
    'upgrade',
]);

function jsonError(message, type, code) {
    return { error: { message, type, code } };
}

function sendJson(response, status, value, extraHeaders = {}) {
    if (response.headersSent || response.writableEnded) {
        return;
    }
    const body = Buffer.from(JSON.stringify(value));
    response.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': body.length,
        ...extraHeaders,
    });
    response.end(body);
}

function safeEqual(left, right) {
    const leftBuffer = Buffer.from(String(left));
    const rightBuffer = Buffer.from(String(right));
    return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

function readLocalKey(request) {
    const authorization = request.headers.authorization;
    if (typeof authorization === 'string') {
        const match = authorization.match(/^Bearer\s+(.+)$/i);
        if (match) {
            return match[1];
        }
    }
    const alternate = request.headers['x-api-key'] ?? request.headers['api-key'];
    return Array.isArray(alternate) ? alternate[0] : alternate;
}

async function readJson(request, maxBytes) {
    const chunks = [];
    let size = 0;
    for await (const chunk of request) {
        size += chunk.length;
        if (size > maxBytes) {
            const error = new Error('Request body is too large');
            error.status = 413;
            throw error;
        }
        chunks.push(chunk);
    }
    try {
        return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
        const error = new Error('Request body must be valid JSON');
        error.status = 400;
        throw error;
    }
}

function chatCompletionsUrl(baseUrl) {
    const url = new URL(baseUrl);
    const path = url.pathname.replace(/\/+$/, '');
    if (!path.endsWith('/chat/completions')) {
        url.pathname = `${path}/chat/completions`;
    }
    return url.toString();
}

function shouldRetryStatus(retryStatusCodes, status) {
    return retryStatusCodes === 'all' || retryStatusCodes.includes(status);
}

function upstreamHeaders(request, target) {
    const headers = new Headers({
        'Content-Type': 'application/json',
        'Accept': typeof request.headers.accept === 'string' ? request.headers.accept : 'application/json, text/event-stream',
        'User-Agent': 'SillyTavern-OpenAI-Round-Robin/0.1.0',
    });

    for (const [key, value] of Object.entries(target.headers)) {
        if (!HOP_BY_HOP_HEADERS.has(key.toLowerCase())) {
            headers.set(key, value);
        }
    }
    if (target.apiKey) {
        headers.set(target.authHeader, target.authScheme ? `${target.authScheme} ${target.apiKey}` : target.apiKey);
    }
    return headers;
}

function copyResponseHeaders(upstream, response) {
    upstream.headers.forEach((value, key) => {
        if (!HOP_BY_HOP_HEADERS.has(key.toLowerCase())) {
            response.setHeader(key, value);
        }
    });
}

async function discardResponse(response) {
    try {
        await response.body?.cancel();
    } catch {
        // The response is being discarded before a failover attempt.
    }
}

function fetchContext(request, response, timeoutMs) {
    const controller = new AbortController();
    let clientAborted = false;
    let timedOut = false;

    const abortForClient = () => {
        if (!response.writableEnded) {
            clientAborted = true;
            controller.abort(new Error('Client disconnected'));
        }
    };
    request.once('aborted', abortForClient);
    response.once('close', abortForClient);
    const timer = setTimeout(() => {
        timedOut = true;
        controller.abort(new Error('Upstream request timed out'));
    }, timeoutMs);

    return {
        signal: controller.signal,
        clientAborted: () => clientAborted,
        timedOut: () => timedOut,
        cleanup() {
            clearTimeout(timer);
            request.off('aborted', abortForClient);
            response.off('close', abortForClient);
        },
    };
}

function createStats(targets) {
    return {
        totalRequests: 0,
        successfulRequests: 0,
        failedRequests: 0,
        failoverAttempts: 0,
        targets: Object.fromEntries(targets.map(target => [target.name, {
            attempts: 0,
            successes: 0,
            failures: 0,
        }])),
    };
}

export function createProxyServer(config, options = {}) {
    const fetchImpl = options.fetchImpl ?? globalThis.fetch;
    const logger = options.logger ?? console;
    const scheduler = new RoundRobinScheduler(config.targets);
    const stats = createStats(config.targets);
    let requestSequence = 0;
    let server;

    async function proxyUpstream(upstream, response, target, attempt) {
        response.statusCode = upstream.status;
        if (typeof upstream.statusText === 'string' && upstream.statusText) {
            response.statusMessage = upstream.statusText;
        }
        copyResponseHeaders(upstream, response);
        if (config.routing.exposeTargetHeader) {
            response.setHeader('X-Round-Robin-Target', target.name);
            response.setHeader('X-Round-Robin-Attempt', String(attempt));
        }
        if (!upstream.body) {
            response.end();
            return;
        }
        await pipeline(Readable.fromWeb(upstream.body), response);
    }

    async function handleChatCompletion(request, response) {
        let payload;
        try {
            payload = await readJson(request, config.server.requestBodyLimitBytes);
        } catch (error) {
            sendJson(response, error.status ?? 400, jsonError(error.message, 'invalid_request_error', 'invalid_json'));
            return;
        }
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
            sendJson(response, 400, jsonError('Request body must be a JSON object', 'invalid_request_error', 'invalid_body'));
            return;
        }

        const publicModel = typeof payload.model === 'string' && payload.model.trim()
            ? payload.model.trim()
            : config.routing.defaultModel;
        const poolSize = scheduler.poolSize(publicModel);
        if (!poolSize) {
            sendJson(response, 404, jsonError(`No enabled target is configured for model '${publicModel}'`, 'invalid_request_error', 'model_not_found'));
            return;
        }

        const configuredMax = config.routing.failover.maxAttempts;
        const maxAttempts = config.routing.failover.enabled
            ? Math.min(poolSize, configuredMax > 0 ? configuredMax : poolSize)
            : 1;
        const requestId = ++requestSequence;
        const excluded = new Set();
        const failures = [];
        stats.totalRequests++;

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            const target = scheduler.next(publicModel, excluded);
            if (!target) {
                break;
            }
            excluded.add(target.id);
            stats.targets[target.name].attempts++;
            if (attempt > 1) {
                stats.failoverAttempts++;
            }
            logger.info?.(`[openai-round-robin] request=${requestId} attempt=${attempt}/${maxAttempts} target=${target.name} model=${target.model}`);

            const context = fetchContext(request, response, config.server.upstreamTimeoutMs);
            let upstream;
            try {
                upstream = await fetchImpl(chatCompletionsUrl(target.baseUrl), {
                    method: 'POST',
                    headers: upstreamHeaders(request, target),
                    body: JSON.stringify({ ...payload, model: target.model }),
                    redirect: 'follow',
                    signal: context.signal,
                });
            } catch (error) {
                context.cleanup();
                stats.targets[target.name].failures++;
                failures.push({
                    target: target.name,
                    reason: context.timedOut() ? 'timeout' : 'network_error',
                });
                if (context.clientAborted()) {
                    return;
                }
                if (attempt < maxAttempts) {
                    continue;
                }
                stats.failedRequests++;
                sendJson(response, 502, jsonError('All configured upstream attempts failed', 'upstream_error', 'all_targets_failed'), {
                    'X-Round-Robin-Failures': String(failures.length),
                });
                logger.warn?.(`[openai-round-robin] request=${requestId} failed: ${error.message}`);
                return;
            }

            const canFailover = !upstream.ok
                && config.routing.failover.enabled
                && shouldRetryStatus(config.routing.failover.retryStatusCodes, upstream.status)
                && attempt < maxAttempts;
            if (canFailover) {
                context.cleanup();
                stats.targets[target.name].failures++;
                failures.push({ target: target.name, status: upstream.status });
                logger.warn?.(`[openai-round-robin] request=${requestId} target=${target.name} returned HTTP ${upstream.status}; trying next target`);
                await discardResponse(upstream);
                continue;
            }

            try {
                await proxyUpstream(upstream, response, target, attempt);
                if (upstream.ok) {
                    stats.successfulRequests++;
                    stats.targets[target.name].successes++;
                } else {
                    stats.failedRequests++;
                    stats.targets[target.name].failures++;
                }
            } catch (error) {
                stats.failedRequests++;
                stats.targets[target.name].failures++;
                logger.warn?.(`[openai-round-robin] request=${requestId} stream from target=${target.name} ended early: ${error.message}`);
                if (!response.headersSent) {
                    sendJson(response, 502, jsonError('The upstream response stream failed', 'upstream_error', 'stream_failed'));
                }
            } finally {
                context.cleanup();
            }
            return;
        }

        stats.failedRequests++;
        sendJson(response, 502, jsonError('No upstream target was available', 'upstream_error', 'no_target_available'));
    }

    async function handler(request, response) {
        const url = new URL(request.url, 'http://127.0.0.1');
        if (request.method === 'GET' && url.pathname === '/health') {
            sendJson(response, 200, {
                status: 'ok',
                enabledTargets: config.targets.filter(target => target.enabled).length,
                models: scheduler.models(),
            });
            return;
        }

        const suppliedKey = readLocalKey(request);
        if (!suppliedKey || !safeEqual(suppliedKey, config.server.apiKey)) {
            sendJson(response, 401, jsonError('Invalid local API key', 'authentication_error', 'invalid_api_key'), {
                'WWW-Authenticate': 'Bearer',
            });
            return;
        }

        if (request.method === 'GET' && ['/v1/models', '/models'].includes(url.pathname)) {
            sendJson(response, 200, {
                object: 'list',
                data: scheduler.models().map(model => ({
                    id: model,
                    object: 'model',
                    created: 0,
                    owned_by: 'sillytavern-openai-round-robin',
                })),
            });
            return;
        }
        if (request.method === 'GET' && ['/status', '/v1/status'].includes(url.pathname)) {
            sendJson(response, 200, {
                stats,
                pools: scheduler.snapshot(),
            });
            return;
        }
        if (request.method === 'POST' && ['/v1/chat/completions', '/chat/completions'].includes(url.pathname)) {
            await handleChatCompletion(request, response);
            return;
        }

        sendJson(response, 404, jsonError('Route not found', 'invalid_request_error', 'not_found'));
    }

    return {
        get server() {
            return server;
        },
        scheduler,
        stats,
        async start(overrides = {}) {
            if (server) {
                throw new Error('Proxy server is already running');
            }
            server = http.createServer((request, response) => {
                handler(request, response).catch(error => {
                    logger.error?.('[openai-round-robin] unhandled request error', error);
                    sendJson(response, 500, jsonError('Internal proxy error', 'proxy_error', 'internal_error'));
                });
            });
            await new Promise((resolve, reject) => {
                server.once('error', reject);
                server.listen(overrides.port ?? config.server.port, overrides.host ?? config.server.host, resolve);
            });
            return server.address();
        },
        async close() {
            if (!server) {
                return;
            }
            const activeServer = server;
            server = undefined;
            activeServer.closeAllConnections?.();
            await new Promise(resolve => activeServer.close(resolve));
        },
    };
}
