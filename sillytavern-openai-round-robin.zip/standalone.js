import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { startRuntime } from './src/runtime.js';

const pluginDirectory = path.dirname(fileURLToPath(import.meta.url));
const proxy = await startRuntime({ pluginDirectory });

let closing = false;
async function close() {
    if (closing) {
        return;
    }
    closing = true;
    await proxy.close();
    process.exit(0);
}

process.on('SIGINT', close);
process.on('SIGTERM', close);

