import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { startRuntime } from './src/runtime.js';

const pluginDirectory = path.dirname(fileURLToPath(import.meta.url));
let proxy;

export const info = {
    id: 'openai-round-robin',
    name: 'OpenAI Round Robin Proxy',
    description: 'Loopback-only OpenAI-compatible endpoint, key and model round-robin proxy.',
};

export async function init(_router) {
    proxy = await startRuntime({ pluginDirectory });
}

export async function exit() {
    await proxy?.close();
    proxy = undefined;
}

