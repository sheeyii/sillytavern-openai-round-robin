import assert from 'node:assert/strict';
import http from 'node:http';
import { after, before, describe, it } from 'node:test';

import { ConfigError, parseConfig } from '../src/config.js';
import { createProxyServer } from '../src/proxy-server.js';

const silentLogger = {
    info() {},
    warn() {},
    error(error) { throw error; },
};

const upstreams = [];

function readRequestBody(request) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        request.on('data', chunk => chunks.push(chunk));
        request.on('end', () => {
            try {
                resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
            } catch (error) {
                reject(error);
            }
        });
        request.on('error', reject);
    });
}

async function createUpstream({ name, status = 200, stream = false, responseModel, onRequest } = {}) {
    const requests = [];
    const server = http.createServer(async (request, response) => {
        const body = await readRequestBody(request);
        const record = {
            authorization: request.headers.authorization,
            body,
        };
        requests.push(record);
        await onRequest?.(record);

        if (status !== 200) {
            const errorBody = JSON.stringify({ error: { message: `${name} failed`, type: 'upstream_error' } });
            response.writeHead(status, { 'Content-Type': 'application/json' });
            response.end(errorBody);
            return;
        }

        if (stream) {
            response.writeHead(200, { 'Content-Type': 'text/event-stream' });
            response.write(`data: ${JSON.stringify({ id: `chatcmpl-${name}`, model: responseModel ?? body.model, choices: [{ delta: { content: 'hello' } }] })}\n\n`);
            response.end('data: [DONE]\n\n');
            return;
        }

        const result = JSON.stringify({
            id: `chatcmpl-${name}`,
            object: 'chat.completion',
            model: responseModel ?? body.model,
            choices: [{ index: 0, message: { role: 'assistant', content: name }, finish_reason: 'stop' }],
        });
        response.writeHead(200, { 'Content-Type': 'application/json' });
        response.end(result);
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const address = server.address();
    const result = {
        baseUrl: `http://127.0.0.1:${address.port}/v1`,
        requests,
        async close() {
            server.closeAllConnections?.();
            await new Promise(resolve => server.close(resolve));
        },
    };
    upstreams.push(result);
    return result;
}

function makeConfig(targets, overrides = {}) {
    return parseConfig({
        server: {
            host: '127.0.0.1',
            port: 35697,
            apiKey: 'local-test-key',
            upstreamTimeoutMs: 5000,
        },
        routing: {
            defaultModel: 'text',
            failover: {
                enabled: true,
                maxAttempts: 0,
                retryStatusCodes: 'all',
            },
            ...overrides.routing,
        },
        targets,
    });
}

async function withProxy(config, callback) {
    const proxy = createProxyServer(config, { logger: silentLogger });
    const address = await proxy.start({ host: '127.0.0.1', port: 0 });
    try {
        return await callback(`http://127.0.0.1:${address.port}`, proxy);
    } finally {
        await proxy.close();
    }
}

function target(name, upstream, apiKey, model, extra = {}) {
    return {
        name,
        enabled: true,
        publicModel: 'text',
        baseUrl: upstream.baseUrl,
        apiKey,
        model,
        ...extra,
    };
}

before(() => {});
after(async () => {
    await Promise.all(upstreams.splice(0).map(upstream => upstream.close()));
});

describe('OpenAI round-robin proxy', () => {
    it('keeps different public models in independent pools', async () => {
        const text = await createUpstream({ name: 'text' });
        const summary = await createUpstream({ name: 'summary' });
        const config = makeConfig([
            target('text', text, 'key-text', 'gpt-text'),
            target('summary', summary, 'key-summary', 'gpt-summary', { publicModel: 'summary' }),
        ]);

        await withProxy(config, async baseUrl => {
            const request = model => fetch(`${baseUrl}/v1/chat/completions`, {
                method: 'POST',
                headers: { Authorization: 'Bearer local-test-key', 'Content-Type': 'application/json' },
                body: JSON.stringify({ model, messages: [] }),
            });
            const response = await request('summary');
            assert.equal(response.status, 200);
            assert.equal(response.headers.get('x-round-robin-target'), 'summary');
            assert.equal((await response.json()).model, 'gpt-summary');
            assert.equal(text.requests.length, 0);
        });
    });

    it('rotates targets in order, including duplicate URLs with different keys and models', async () => {
        const first = await createUpstream({ name: 'first' });
        const second = await createUpstream({ name: 'second' });
        const third = await createUpstream({ name: 'third' });
        const fourth = await createUpstream({ name: 'fourth' });
        const config = makeConfig([
            target('one', first, 'key-1', 'gpt1'),
            target('two', second, 'key-2', 'gpt2'),
            target('three', third, 'key-3', 'gpt3'),
            target('four', fourth, 'key-4', 'gpt4'),
        ]);

        await withProxy(config, async baseUrl => {
            const observed = [];
            for (let index = 0; index < 5; index++) {
                const response = await fetch(`${baseUrl}/v1/chat/completions`, {
                    method: 'POST',
                    headers: { Authorization: 'Bearer local-test-key', 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model: 'text', messages: [{ role: 'user', content: `message-${index}` }] }),
                });
                assert.equal(response.status, 200);
                observed.push({
                    target: response.headers.get('x-round-robin-target'),
                    body: await response.json(),
                });
            }

            assert.deepEqual(observed.map(item => item.target), ['one', 'two', 'three', 'four', 'one']);
            assert.deepEqual(observed.map(item => item.body.model), ['gpt1', 'gpt2', 'gpt3', 'gpt4', 'gpt1']);
            assert.equal(first.requests[0].authorization, 'Bearer key-1');
            assert.equal(second.requests[0].authorization, 'Bearer key-2');
            assert.equal(third.requests[0].authorization, 'Bearer key-3');
            assert.equal(fourth.requests[0].authorization, 'Bearer key-4');
        });
    });

    it('fails over to the next target and continues rotation after the failed attempt', async () => {
        const failing = await createUpstream({ name: 'failing', status: 503 });
        const second = await createUpstream({ name: 'second' });
        const third = await createUpstream({ name: 'third' });
        const config = makeConfig([
            target('failing', failing, 'key-f', 'bad-model'),
            target('second', second, 'key-2', 'good-model'),
            target('third', third, 'key-3', 'good-model-2'),
        ]);

        await withProxy(config, async baseUrl => {
            const request = () => fetch(`${baseUrl}/v1/chat/completions`, {
                method: 'POST',
                headers: { Authorization: 'Bearer local-test-key', 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'text', messages: [] }),
            });
            const firstResponse = await request();
            assert.equal(firstResponse.status, 200);
            assert.equal(firstResponse.headers.get('x-round-robin-target'), 'second');
            assert.equal((await firstResponse.json()).model, 'good-model');

            const secondResponse = await request();
            assert.equal(secondResponse.status, 200);
            assert.equal(secondResponse.headers.get('x-round-robin-target'), 'third');
            assert.equal((await secondResponse.json()).model, 'good-model-2');
            assert.equal(failing.requests.length, 1);
        });
    });

    it('can disable failover and preserves an upstream error response', async () => {
        const failing = await createUpstream({ name: 'failing', status: 401 });
        const second = await createUpstream({ name: 'second' });
        const config = makeConfig([
            target('failing', failing, 'key-f', 'bad-model'),
            target('second', second, 'key-2', 'good-model'),
        ], { routing: { failover: { enabled: false, maxAttempts: 0, retryStatusCodes: 'all' } } });

        await withProxy(config, async baseUrl => {
            const response = await fetch(`${baseUrl}/v1/chat/completions`, {
                method: 'POST',
                headers: { Authorization: 'Bearer local-test-key', 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'text', messages: [] }),
            });
            assert.equal(response.status, 401);
            assert.equal(response.headers.get('x-round-robin-target'), 'failing');
            assert.equal((await response.json()).error.message, 'failing failed');
            assert.equal(second.requests.length, 0);
        });
    });

    it('passes through streaming responses without buffering them', async () => {
        const upstream = await createUpstream({ name: 'stream', stream: true });
        const config = makeConfig([target('stream', upstream, 'key-s', 'stream-model')]);

        await withProxy(config, async baseUrl => {
            const response = await fetch(`${baseUrl}/v1/chat/completions`, {
                method: 'POST',
                headers: { Authorization: 'Bearer local-test-key', 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'text', stream: true, messages: [] }),
            });
            assert.equal(response.status, 200);
            assert.match(await response.text(), /data: \[DONE\]/);
            assert.equal(response.headers.get('content-type'), 'text/event-stream');
        });
    });

    it('requires the local key and exposes only configured public models', async () => {
        const upstream = await createUpstream({ name: 'model' });
        const config = makeConfig([target('model', upstream, 'key', 'upstream-model')]);

        await withProxy(config, async baseUrl => {
            const unauthorized = await fetch(`${baseUrl}/v1/models`);
            assert.equal(unauthorized.status, 401);

            const models = await fetch(`${baseUrl}/v1/models`, {
                headers: { Authorization: 'Bearer local-test-key' },
            });
            assert.equal(models.status, 200);
            assert.deepEqual((await models.json()).data.map(model => model.id), ['text']);
        });
    });

    it('rejects unsafe or ambiguous configuration', () => {
        assert.throws(() => parseConfig({
            server: { host: '0.0.0.0', apiKey: 'local' },
            targets: [],
        }), ConfigError);
        assert.throws(() => parseConfig({
            server: { apiKey: 'local' },
            routing: { failover: { maxAttempts: -1 } },
            targets: [],
        }), ConfigError);
        assert.throws(() => parseConfig({
            server: { apiKey: 'local' },
            targets: [
                { name: 'same', baseUrl: 'https://one.example/v1', model: 'one' },
                { name: 'same', baseUrl: 'https://two.example/v1', model: 'two' },
            ],
        }), ConfigError);
    });
});
