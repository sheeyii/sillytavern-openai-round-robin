# SillyTavern OpenAI Round Robin

为 SillyTavern 提供一个只监听本机回环地址的 OpenAI 兼容代理。每个聊天补全请求按配置顺序选择下一组 `API 地址 + API Key + 模型`，并可在上游失败时自动切换。

## 为什么使用本地代理

SillyTavern 的 OpenAI 兼容连接在任意时刻使用一组已激活的地址、Key 和模型。连接配置可以保存多套预设，但本身不会按每条请求自动轮询。

本插件不修改 SillyTavern 的请求代码和全局设置，而是在 `127.0.0.1:35697` 提供一个普通的 OpenAI 兼容端点。SillyTavern 以及选择“跟随当前酒馆连接”的扩展都会把它当成单一 API 使用，轮询逻辑完全留在代理内部。

## 功能

- 严格按配置顺序轮询，每个请求消费一个轮询项。
- 相同 API 地址可以配置多次，每次使用不同 Key 或模型。
- 不同 API 地址可以使用完全不同的上游模型。
- 按 `publicModel` 建立多个独立轮询池。
- 可开关失败切换，可限制一次请求最多尝试多少个目标。
- 支持普通响应和 SSE 流式响应。
- 透传消息、工具调用、图片内容、`response_format`、采样参数等请求字段，只替换上游 `model`。
- 提供 `/v1/models`、`/health` 和脱敏后的 `/v1/status`。
- 强制只监听 `127.0.0.1` 或 `::1`，上游 Key 不会返回给客户端或写入日志。
- 除 Node.js 20 外没有第三方运行依赖。

## 作为 SillyTavern 服务端插件安装

将整个目录放入 SillyTavern 的插件目录：

```text
SillyTavern/
└── plugins/
    └── openai-round-robin/
        ├── index.js
        ├── package.json
        ├── config.example.json
        └── src/
```

在 SillyTavern 的 `config.yaml` 中启用服务端插件：

```yaml
enableServerPlugins: true
```

首次启动时插件会从 `config.example.json` 自动创建被 `.gitignore` 忽略的 `config.json`。编辑 `config.json`，填写本地 Key、上游信息并把需要使用的目标设为 `"enabled": true`，然后重启 SillyTavern。

本地开发目录也可以直接复制：

```bash
cp -R sillytavern-openai-round-robin /path/to/SillyTavern/plugins/openai-round-robin
```

## 作为独立代理运行

不支持服务端插件的 SillyTavern 发行方式，可以单独运行代理：

```bash
cp config.example.json config.json
# 编辑 config.json
npm start
```

也可以通过环境变量指定配置文件：

```bash
ST_OPENAI_ROUND_ROBIN_CONFIG=/absolute/path/config.json npm start
```

## SillyTavern 连接设置

在“API 连接 -> 聊天补全”中选择自定义 OpenAI 兼容来源，并设置：

```text
API URL: http://127.0.0.1:35697/v1
API Key: config.json 中 server.apiKey 的值
Model:   text
```

不要把任何上游 Key 填进 SillyTavern。酒馆中保存的只是本地代理 Key。

## 配置示例

以下四项会按 `fengwind -> ggchan -> unsnow-primary -> unsnow-secondary-key -> fengwind` 循环。最后两项可以使用相同地址但不同 Key 和模型。

```json
{
  "server": {
    "host": "127.0.0.1",
    "port": 35697,
    "apiKey": "replace-with-a-local-only-key",
    "requestBodyLimitMb": 32,
    "upstreamTimeoutMs": 120000
  },
  "routing": {
    "defaultModel": "text",
    "exposeTargetHeader": true,
    "failover": {
      "enabled": true,
      "maxAttempts": 0,
      "retryStatusCodes": "all"
    }
  },
  "targets": [
    {
      "name": "fengwind",
      "enabled": true,
      "publicModel": "text",
      "baseUrl": "https://api.fengwind.com/v1",
      "apiKey": "key-1",
      "model": "gpt1"
    },
    {
      "name": "ggchan",
      "enabled": true,
      "publicModel": "text",
      "baseUrl": "https://gcli.ggchan.dev/v1",
      "apiKey": "key-2",
      "model": "gpt2"
    },
    {
      "name": "unsnow-primary",
      "enabled": true,
      "publicModel": "text",
      "baseUrl": "https://api.unsnow.org/v1",
      "apiKey": "key-3",
      "model": "gpt3"
    },
    {
      "name": "unsnow-secondary-key",
      "enabled": true,
      "publicModel": "text",
      "baseUrl": "https://api.unsnow.org/v1",
      "apiKey": "key-4",
      "model": "gpt4"
    }
  ]
}
```

### 多个独立轮询池

`publicModel` 相同的目标属于同一个池。要建立另一组独立轮询，可以给目标设置另一个 `publicModel`，例如 `summary`，然后让客户端请求模型 `summary`。`GET /v1/models` 会同时列出 `text` 和 `summary`。

### 特殊鉴权头

默认上游鉴权为：

```text
Authorization: Bearer <apiKey>
```

个别兼容接口使用其他请求头时，可以在目标中配置：

```json
{
  "authHeader": "x-api-key",
  "authScheme": "",
  "headers": {
    "X-Custom-Header": "value"
  }
}
```

## 失败切换语义

`routing.failover.enabled` 控制是否切换。`maxAttempts` 为 `0` 时，一次请求最多把当前轮询池中的每个目标尝试一遍；设为正整数可以限制次数。

`retryStatusCodes` 可以是 `"all"`，也可以是状态码数组：

```json
"retryStatusCodes": [408, 425, 429, 500, 502, 503, 504]
```

网络错误和超时在开启失败切换时也会尝试下一项。每次尝试都会推进轮询位置。例如第一项失败、第二项成功后，下一个请求从第三项开始。

对于流式响应，代理只能在上游返回 HTTP 响应头之前或返回错误状态码时切换。上游已经返回 `200` 且内容开始发送后再断线，代理不会重新生成，因为重试可能造成重复文本、重复工具调用和重复计费。

## 与其他扩展的关系

- 扩展选择“跟随当前 SillyTavern API”时，它的聊天补全请求也会经过本代理，通常无需额外适配。
- 扩展自行配置了独立 API 地址时，它会绕过本代理。
- 轮询单位是一次 `/chat/completions` 请求，不是界面上可见的用户消息。重新生成、继续生成、后台总结或正文润色都会各自消费一个轮询项。
- 代理不修改 SillyTavern 保存的连接配置，因此不会在请求期间来回切换全局 Key，也不会与连接管理器争用设置状态。

## 状态检查

```bash
curl http://127.0.0.1:35697/health

curl \
  -H 'Authorization: Bearer replace-with-a-local-only-key' \
  http://127.0.0.1:35697/v1/status
```

响应只包含目标名称、模型、计数和轮询位置，不包含地址或 Key。响应头 `X-Round-Robin-Target` 可用于确认本次实际选择的目标；不需要时将 `exposeTargetHeader` 设为 `false`。

## 测试

```bash
npm test
```

